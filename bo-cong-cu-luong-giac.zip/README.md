# bo-cong-cu-luong-giac
Phiên bản chạy nhanh của **Bộ công cụ góc lượng giác** — Vite + React + Tailwind + Framer Motion.

## Cài đặt
Yêu cầu: Node.js (>=16).

1. Giải nén thư mục hoặc clone dự án.
2. Mở terminal vào thư mục dự án, chạy:

```bash
npm install
npm run dev
```

Ứng dụng sẽ chạy ở `http://localhost:5173` (mặc định).

## Gợi ý nâng cấp
- Thêm Tailwind UI hoặc shadcn/ui cho giao diện sẵn có.
- Thêm chế độ bài tập, lưu trạng thái học sinh (localStorage hoặc server).
- Thêm xuất PDF / in để sử dụng trên lớp.
