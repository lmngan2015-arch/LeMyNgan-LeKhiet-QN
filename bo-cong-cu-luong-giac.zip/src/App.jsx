import React, { useState, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'

export default function App() {
  const size = 420
  const cx = size / 2
  const cy = size / 2
  const radius = 150

  const [point, setPoint] = useState({ x: cx + radius, y: cy })
  const [isDragging, setIsDragging] = useState(false)
  const [unit, setUnit] = useState('deg')
  const [showOptions, setShowOptions] = useState({
    opposite: true,
    supplement: true,
    plusPi: false,
    complementary: false,
    reflex: false
  })

  const svgRef = useRef(null)

  useEffect(() => {
    function up() { setIsDragging(false) }
    window.addEventListener('mouseup', up)
    return () => window.removeEventListener('mouseup', up)
  }, [])

  function toAngle(x, y) {
    const dx = x - cx
    const dy = cy - y
    const a = Math.atan2(dy, dx)
    return a >= 0 ? a : a + 2 * Math.PI
  }

  function angleDisplay(a) {
    return unit === 'deg' ? (a * 180 / Math.PI).toFixed(2) + '°' : a.toFixed(4) + ' rad'
  }

  function onPointerDown() { setIsDragging(true) }

  function onPointerMove(e) {
    if (!isDragging) return
    const svg = svgRef.current
    const pt = svg.createSVGPoint()
    pt.x = e.clientX; pt.y = e.clientY
    const cursor = pt.matrixTransform(svg.getScreenCTM().inverse())
    const dx = cursor.x - cx; const dy = cursor.y - cy
    const len = Math.sqrt(dx*dx + dy*dy) || 1
    const nx = cx + (dx / len) * radius; const ny = cy + (dy / len) * radius
    setPoint({ x: nx, y: ny })
  }

  const a = toAngle(point.x, point.y)
  const normalize = (x) => ((x % (2*Math.PI)) + 2*Math.PI) % (2*Math.PI)
  const aOpp = normalize(2*Math.PI - a)
  const aSupp = normalize(Math.PI - a)

  const resetToZero = () => setPoint({ x: cx + radius, y: cy })

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-b from-white to-gray-100">
      <div className="w-full max-w-5xl">
        <motion.h1 className="text-2xl md:text-3xl font-bold text-center text-sky-700 mb-4" initial={{opacity:0, y:-8}} animate={{opacity:1, y:0}}>Bộ công cụ góc lượng giác</motion.h1>
        <motion.p className="text-center text-gray-600 mb-6" initial={{opacity:0}} animate={{opacity:1}}>Kéo điểm <strong>M</strong> trên vòng tròn để thay đổi góc. Phiên bản responsive để dùng trong giảng dạy.</motion.p>

        <div className="flex flex-col lg:flex-row gap-6 items-start">
          <div className="flex-1 bg-white rounded-xl shadow p-4">
            <svg ref={svgRef} onMouseMove={onPointerMove} width="100%" height="auto" viewBox={`0 0 ${size} ${size}`} className="block mx-auto">
              <circle cx={cx} cy={cy} r={radius} stroke="#111827" strokeWidth={1} fill="none" />
              <circle cx={cx} cy={cy} r={3} fill="#111827" />
              <line x1={cx} y1={cy} x2={point.x} y2={point.y} stroke="#111827" strokeWidth={2} />
              <path d={describeArc(cx, cy, 44, 0, (a*180/Math.PI))} fill="rgba(59,130,246,0.12)" stroke="rgba(59,130,246,0.6)" strokeWidth={1.2} />
              {showOptions.opposite && <path d={describeArc(cx, cy, 36, 0, (aOpp*180/Math.PI))} fill="none" stroke="rgba(220,38,38,0.35)" strokeWidth={2} />}
              {showOptions.supplement && <path d={describeArc(cx, cy, 30, 0, (aSupp*180/Math.PI))} fill="none" stroke="rgba(34,197,94,0.45)" strokeWidth={2} />}
              <circle cx={point.x} cy={point.y} r={10} fill="#0ea5e9" onMouseDown={onPointerDown} style={{cursor:'grab'}} />
            </svg>
          </div>

          <div className="w-full lg:w-80 bg-white rounded-xl shadow p-4 space-y-4">
            <div>
              <h3 className="text-lg font-semibold">Góc hiện tại</h3>
              <div className="font-mono text-2xl text-sky-600">{angleDisplay(a)}</div>
              <div className="text-xs text-gray-500">{a.toFixed(4)} rad • {(a*180/Math.PI).toFixed(2)}°</div>
            </div>

            <div>
              <h3 className="text-lg font-semibold">Chuyển đổi</h3>
              <div className="flex gap-2 mt-2">
                <button className={`px-3 py-1 rounded ${unit==='deg' ? 'bg-sky-600 text-white' : 'bg-gray-100'}`} onClick={()=>setUnit('deg')}>Độ</button>
                <button className={`px-3 py-1 rounded ${unit==='rad' ? 'bg-sky-600 text-white' : 'bg-gray-100'}`} onClick={()=>setUnit('rad')}>Radian</button>
                <button className="px-3 py-1 rounded bg-gray-100" onClick={resetToZero}>Đưa về 0°</button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold">Các góc liên quan</h3>
              <div className="mt-2 space-y-2 text-sm">
                <label className="flex items-center justify-between">
                  <span>Góc đối (−α)</span>
                  <input type="checkbox" checked={showOptions.opposite} onChange={()=>setShowOptions(s=>({...s, opposite:!s.opposite}))} />
                </label>
                <label className="flex items-center justify-between">
                  <span>Góc bù (π − α)</span>
                  <input type="checkbox" checked={showOptions.supplement} onChange={()=>setShowOptions(s=>({...s, supplement:!s.supplement}))} />
                </label>
              </div>
            </div>

            <div className="text-xs text-gray-400 pt-2 border-t">Phiên bản chạy: Vite + React + Tailwind. Mở rộng để thêm bài tập tự chấm.</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function polarToCartesian(cx, cy, radius, angleInDegrees) {
  const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return { x: cx + (radius * Math.cos(angleInRadians)), y: cy + (radius * Math.sin(angleInRadians)) }
}

function describeArc(cx, cy, radius, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, radius, endAngle)
  const end = polarToCartesian(cx, cy, radius, startAngle)
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1'
  const d = ['M', start.x, start.y, 'A', radius, radius, 0, largeArcFlag, 0, end.x, end.y].join(' ')
  return d
}
